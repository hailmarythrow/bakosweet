# Bakosweet Weather Product Recommender

This app uses a local weather forecast to rank the 13 sweet-potato products in the included configuration as `SELL`, `LIMIT`, or `AVOID`.

The product rules are editable in `sweet_potato_products.json`. The app uses only Python's standard library and does not require a database, API key, or private credentials.

## Required software

- Python 3.10 or newer: https://www.python.org/downloads/
- Internet access while the app retrieves forecasts

The forecast service is Open-Meteo: https://open-meteo.com/en/docs

## Install

From the repository root:

### Windows PowerShell

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e .
```

### macOS or Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .
```

There are no runtime dependencies beyond Python. The editable install registers the `bakosweet-recommend` command.

## Run

Replace the coordinates with the local area you want to analyze:

```bash
bakosweet-recommend --lat 34.05 --lon -118.24
```

To request a forecast from 1 to 16 days:

```bash
bakosweet-recommend --lat 34.05 --lon -118.24 --days 3
```

To produce machine-readable JSON:

```bash
bakosweet-recommend --lat 34.05 --lon -118.24 --json > recommendations.json
```

You can also run the source file directly:

```bash
python weather_product_recommender.py --lat 34.05 --lon -118.24
```

## Customize products

Edit `sweet_potato_products.json`. Each product can define:

- Preferred minimum and maximum temperature in Celsius
- Rain, sunshine, precipitation, wind, and snow scoring effects
- Selling price, unit cost, and spoilage risk
- Product-specific `SELL` and `LIMIT` score cutoffs

Positive weather effects increase a product's score; negative effects reduce it. The included values are starter assumptions and should be calibrated against actual sales history.

## Test

```bash
python -m unittest discover -s . -p "test_*.py"
```

## Build verification

This is a lightweight Python CLI, so it has no frontend compilation step. The package build is verified with:

```bash
python -m build
```

If the `build` module is not installed, install it temporarily with `python -m pip install build`, then repeat the command.

## Environment variables and credentials

None are required. No `.env` file is needed. The repository intentionally contains no API keys, passwords, tokens, or private credentials.
