import json
import unittest
from pathlib import Path

from weather_product_recommender import Product, normalize_weather, score_product


class WeatherProductTests(unittest.TestCase):
    def test_product_config_has_thirteen_products(self):
        config_path = Path(__file__).with_name("sweet_potato_products.json")
        config = json.loads(config_path.read_text(encoding="utf-8"))
        self.assertEqual(len(config["products"]), 13)

    def test_warm_weather_favors_product_in_its_temperature_range(self):
        product = Product(
            name="Test product", category="Test", price=10, unit_cost=4,
            ideal_min_temp_c=10, ideal_max_temp_c=25,
            rain_effect=0, sun_effect=0, wind_effect=0, snow_effect=0,
            precipitation_effect=0, spoilage_risk=0,
        )
        score, reasons = score_product(product, {"average_temp": 18, "rain": 0, "sun": 0, "wind": 0, "snow": 0, "precipitation": 0})
        self.assertGreater(score, 0)
        self.assertIn("temperature is favorable", reasons)

    def test_weather_normalization(self):
        daily = {
            "temperature_2m_max": [20], "temperature_2m_min": [10],
            "precipitation_probability_max": [80], "precipitation_sum": [10],
            "snowfall_sum": [0], "wind_speed_10m_max": [25],
            "sunshine_duration": [21600],
        }
        weather = normalize_weather(daily, 0)
        self.assertEqual(weather["average_temp"], 15)
        self.assertEqual(weather["rain"], 0.8)


if __name__ == "__main__":
    unittest.main()
