"""Customizable weather-based product recommendation engine."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any
from urllib.parse import urlencode
from urllib.request import Request, urlopen

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
DEFAULT_CONFIG = Path(__file__).with_name("sweet_potato_products.json")


@dataclass(frozen=True)
class Product:
    name: str
    category: str
    price: float
    unit_cost: float
    ideal_min_temp_c: float
    ideal_max_temp_c: float
    rain_effect: float
    sun_effect: float
    wind_effect: float
    snow_effect: float
    precipitation_effect: float
    spoilage_risk: float
    sell_cutoff: float = 0.45
    limit_cutoff: float = 0.22

    @property
    def margin_rate(self) -> float:
        return max(0.0, (self.price - self.unit_cost) / max(self.price, 0.01))

    @classmethod
    def from_dict(cls, item: dict[str, Any]) -> "Product":
        conditions = item["conditions"]
        economics = item.get("economics", {})
        rules = item.get("recommendation_rules", {})
        return cls(
            name=item["name"], category=item.get("category", "Uncategorized"),
            price=float(economics.get("price", 0)), unit_cost=float(economics.get("unit_cost", 0)),
            ideal_min_temp_c=float(conditions.get("ideal_min_temp_c", -99)),
            ideal_max_temp_c=float(conditions.get("ideal_max_temp_c", 99)),
            rain_effect=float(conditions.get("rain_effect", 0)),
            sun_effect=float(conditions.get("sun_effect", 0)),
            wind_effect=float(conditions.get("wind_effect", 0)),
            snow_effect=float(conditions.get("snow_effect", 0)),
            precipitation_effect=float(conditions.get("precipitation_effect", 0)),
            spoilage_risk=float(economics.get("spoilage_risk", 0)),
            sell_cutoff=float(rules.get("sell_cutoff", 0.45)),
            limit_cutoff=float(rules.get("limit_cutoff", 0.22)),
        )


def load_products(config_path: Path) -> list[Product]:
    with config_path.open(encoding="utf-8") as file:
        return [Product.from_dict(item) for item in json.load(file)["products"]]


def fetch_forecast(latitude: float, longitude: float, days: int = 7) -> dict[str, Any]:
    params = {
        "latitude": latitude, "longitude": longitude, "timezone": "auto", "forecast_days": days,
        "daily": ",".join([
            "temperature_2m_max", "temperature_2m_min", "precipitation_probability_max",
            "precipitation_sum", "snowfall_sum", "wind_speed_10m_max", "sunshine_duration",
        ]),
    }
    request = Request(f"{FORECAST_URL}?{urlencode(params)}", headers={"User-Agent": "weather-product-recommender/1.0"})
    with urlopen(request, timeout=20) as response:
        return json.load(response)


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def normalize_weather(daily: dict[str, list[Any]], index: int) -> dict[str, float]:
    max_temp = float(daily["temperature_2m_max"][index])
    min_temp = float(daily["temperature_2m_min"][index])
    return {
        "average_temp": (max_temp + min_temp) / 2,
        "rain": clamp(float(daily["precipitation_probability_max"][index] or 0) / 100),
        "precipitation": clamp(float(daily["precipitation_sum"][index] or 0) / 20),
        "snow": clamp(float(daily["snowfall_sum"][index] or 0) / 5),
        "wind": clamp(float(daily["wind_speed_10m_max"][index] or 0) / 50),
        "sun": clamp(float(daily["sunshine_duration"][index] or 0) / 3600 / 12),
    }


def score_product(product: Product, weather: dict[str, float]) -> tuple[float, list[str]]:
    reasons: list[str] = []
    temperature_match = product.ideal_min_temp_c <= weather["average_temp"] <= product.ideal_max_temp_c
    score = 0.35 * (1.0 if temperature_match else 0.25)
    score += product.rain_effect * weather["rain"]
    score += product.sun_effect * weather["sun"]
    score += product.wind_effect * weather["wind"]
    score += product.snow_effect * weather["snow"]
    score += product.precipitation_effect * weather["precipitation"]

    reasons.append("temperature is favorable" if temperature_match else "temperature is outside the preferred range")
    if product.rain_effect and weather["rain"] >= 0.4:
        reasons.append(f"rain probability is {weather['rain']:.0%}")
    if product.precipitation_effect and weather["precipitation"] >= 0.25:
        reasons.append("meaningful precipitation is forecast")
    if product.sun_effect and weather["sun"] >= 0.5:
        reasons.append("sunshine supports demand")
    if product.snow_effect and weather["snow"] > 0:
        reasons.append("snow is forecast")
    if product.wind_effect < 0 and weather["wind"] >= 0.5:
        reasons.append("wind reduces expected demand")

    score *= 0.5 + product.margin_rate
    score *= 1 - 0.35 * clamp(product.spoilage_risk)
    return max(0.0, score), reasons


def recommend(forecast: dict[str, Any], products: list[Product]) -> list[dict[str, Any]]:
    daily = forecast["daily"]
    recommendations = []
    for index, forecast_date in enumerate(daily["time"]):
        weather = normalize_weather(daily, index)
        ranked = []
        for product in products:
            score, reasons = score_product(product, weather)
            decision = "SELL" if score >= product.sell_cutoff else "LIMIT" if score >= product.limit_cutoff else "AVOID"
            ranked.append({"product": product.name, "category": product.category, "score": round(score, 3), "recommendation": decision, "reasons": reasons})
        recommendations.append({
            "date": forecast_date,
            "weather": {
                "average_temp_c": round(weather["average_temp"], 1),
                "rain_probability": round(weather["rain"], 2),
                "precipitation_signal": round(weather["precipitation"], 2),
                "snow_signal": round(weather["snow"], 2),
                "wind_signal": round(weather["wind"], 2),
                "sun_signal": round(weather["sun"], 2),
            },
            "products": sorted(ranked, key=lambda item: item["score"], reverse=True),
        })
    return recommendations


def main() -> None:
    parser = argparse.ArgumentParser(description="Rank products using a local weather forecast.")
    parser.add_argument("--lat", type=float, required=True, help="Location latitude")
    parser.add_argument("--lon", type=float, required=True, help="Location longitude")
    parser.add_argument("--days", type=int, default=7, choices=range(1, 17), help="Forecast horizon, 1-16 days")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG, help="Product rules JSON file")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON")
    args = parser.parse_args()
    result = recommend(fetch_forecast(args.lat, args.lon, args.days), load_products(args.config))
    if args.json:
        print(json.dumps(result, indent=2))
        return
    print(f"Weather-based product recommendations ({date.today().isoformat()})")
    for day in result:
        weather = day["weather"]
        print(f"\n{day['date']}: average {weather['average_temp_c']}°C, rain {weather['rain_probability']:.0%}")
        for item in day["products"]:
            print(f"  {item['recommendation']:5} {item['product']:<48} score={item['score']:.3f} — {', '.join(item['reasons'])}")


if __name__ == "__main__":
    main()
